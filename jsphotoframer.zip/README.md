# photo-framer-js
Canvas Manipulation using image for generating framed photos
